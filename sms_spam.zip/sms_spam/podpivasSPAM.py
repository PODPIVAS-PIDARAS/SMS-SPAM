import time
import sys
import subprocess
import os
subprocess.run('cls', shell=True)
subprocess.run('color 4', shell=True)
def spam_simulator():
    print("\n" + "=" * 50)
    print("WARNING: THIS PROGRAM CREATED ONLY FOR FUNNY")
    print("ITS JOKE ND NO MORE!!")
    print("SKEBOB(wait 3 sec)")
    print("=" * 50 + "\n")
    time.sleep(1.8)
    subprocess.run('color a', shell=True)
    subprocess.run('cls', shell=True)
    try:
        # Ввод параметров
        numb = int(input('Enter a phone number: '))
        time.sleep(1.5)
        subprocess.run('cls', shell=True)
        message = input("Enter a text message: ")
        time.sleep(1.5)
        subprocess.run('cls', shell=True)
        countt = int(input("Enter number of messages: "))
        time.sleep(1.5)
        subprocess.run('cls', shell=True)
        delayy = float(input("Enter the interval between messages (sec): "))
        time.sleep(1.5)
        subprocess.run('cls', shell=True)
        delay = 0.001
        count = 99999
        print("\nSMS spam is started...\n")
        os.system("start cmd /k python SPAM.py")

        # Имитация отправки
        for i in range(1, count + 1):
            print(f"[SMS #{i}] Send: 'FUCK U!!'")
            time.sleep(delay)

        print("\nSMS spam ended!")

    except ValueError:
        print("\nERROR: Uncorrent entering numbers!")
    except KeyboardInterrupt:
        print("\nStopped by user")


if __name__ == "__main__":
    spam_simulator()